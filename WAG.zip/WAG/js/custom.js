$(document).ready(function () {
  var WEBSITE_URL = "http://localhost/wordpress";
  var AJAX_PATH = WEBSITE_URL + "/wp-admin/admin-ajax.php";

  $(".hamburger").click(function () {
    $(this).toggleClass("is-active");
  });

  if ($(".navbar-nav").length) {
    var head = document.getElementsByClassName("navbar-nav")[0];
    var activeTab = head.getElementsByTagName("a");
    for (var i = 0; i < activeTab.length; i++) {
      $(activeTab[i]).click(function () {
        var tab = document.getElementsByClassName("active");
        tab[0].className = tab[0].className.replace("active", "");
        this.className += "active";
      });
    }
  }

  // SPLIDE JS START

  if ($(".splide").length) {
    var splide = new Splide(".splide", {
      perPage: 4,
      focus: 0,
      type: "loop",
      omitEnd: true,
      dots: false,
      mediaQuery: "max",

      breakpoints: {
        1199: {
          perPage: 3,
        },
        992: {
          perPage: 2,
        },
        575: {
          perPage: 1,
        },
      },
    });
    splide.mount();
  }
  // SPLIDE JS END
});

// case studio slider
$(function () {
  var $slide = $("#slide");
  var $nav = $(".nav").find("li");
  var enableNav = true;
  var speed = 1000;

  $slide
    .on("init reInit", function (event, slick) {
      if (!slick.$dots) return;
      $("#slide_paging").html(
        '<b class="page">' +
          (slick.currentSlide + 1) +
          "</b> / " +
          slick.$dots[0].children.length
      );
    })
    .on("beforeChange", function (event, slick, currentSlide, nextSlide) {
      if (enableNav) {
        $nav.removeClass("on");
        $nav.eq(nextSlide).addClass("on");
        navStatus();
      }

      if (!slick.$dots) return;
      var i = (nextSlide ? nextSlide : 0) + 1;
      $("#slide_paging").find(".page").text(i);
    });

  function navStatus() {
    enableNav = false;
    setTimeout(function () {
      enableNav = true;
    }, speed);
  }

  $nav.on("click", function () {
    if (enableNav) {
      var slideNo = $(this).index();
      $slide.slick("slickGoTo", slideNo);
      $nav.removeClass("on");
      $(this).addClass("on");
      $("#slide_paging")
        .find(".page")
        .text(slideNo + 1);
      navStatus();
    }
  });

  // /* * /
  // $slide.slick({
  //   arrows: true,
  //   dots: true,
  //   infinite: true,
  //   autoplay: false,
  //   fade: false,
  //   speed: speed,
  //   draggable: true,
  //   slidesToShow: 1,
  //   slidesToScroll: 1,
  // });
  // /* */
});

// case studio slider

jQuery(function ($) {
  const listItems = document.querySelectorAll(".category-filter");
  const checkboxes_categories = Array.from(listItems);

  const hexItems = document.querySelectorAll(".hex-filter");
  const checkboxes_hex = Array.from(hexItems);

  const threadItems = document.querySelectorAll(".thread-filter");
  const checkboxes_thread = Array.from(threadItems);

  const heightItems = document.querySelectorAll(".height-filter");
  const checkboxes_height = Array.from(heightItems);

  const colorItems = document.querySelectorAll(".color-filter");
  const checkboxes_color = Array.from(colorItems);

  const checkboxes = [
    checkboxes_categories,
    checkboxes_hex,
    checkboxes_thread,
    checkboxes_height,
    checkboxes_color,
  ];

  checkboxes.forEach((checkboxGroup) => {
    checkboxGroup.forEach((checkbox) => {
      checkbox.addEventListener("change", function () {
        const selectedCategories = checkboxGroup
          .filter((checkbox) => checkbox.checked)
          .map((checkbox) => checkbox.name);

        if (selectedCategories.length > 0) {
          // Check if any checkbox is selected
          console.log(selectedCategories);

          $.ajax({
            url: "http://localhost/wag/wp-admin/admin-ajax.php",
            type: "POST",
            data: {
              action: "filter_results",
              categories: selectedCategories, // Pass selected categories as an array
            },
            success: function (response) {
              $(".products-gallery-block").html(response);
            },
          });
        } else {
          var selection = "No selection";
          console.log(selection);
          $.ajax({
            url: "http://localhost/wag/wp-admin/admin-ajax.php",
            type: "POST",
            data: {
              action: "show_all_products",
              selection: selection,
            },
            success: function (response) {
              $(".products-gallery-block").html(response);
            },
            error: function (error) {
              // Handle error
              console.log("AJAX request error:", error);
            },
          });
        }
      });
    });
  });
});

$(document).ready(function () {
  $(".product-link").click(function (e) {
    e.preventDefault();
    var newItem = $(this).data("product-id");
    console.log("Product ID:", newItem);
    var existingItems = getCookie("cart_order");

    var updatedItems = [];
    if (existingItems) {
      updatedItems = JSON.parse(existingItems);
    }

    updatedItems.push(newItem);

    var updatedItemsJSON = JSON.stringify(updatedItems);
    var encodedItems = encodeURIComponent(updatedItemsJSON);

    document.cookie = "cart_order=" + encodedItems + "; path=/";
  });

  function getCookie(cookieName) {
    var name = cookieName + "=";
    var decodedCookie = decodeURIComponent(document.cookie);
    var cookieArray = decodedCookie.split(";");

    for (var i = 0; i < cookieArray.length; i++) {
      var cookie = cookieArray[i];
      while (cookie.charAt(0) === " ") {
        cookie = cookie.substring(1);
      }
      if (cookie.indexOf(name) === 0) {
        return cookie.substring(name.length, cookie.length);
      }
    }

    return null;
  }

  function toggleQuantityEdit(element) {
    var quantityElement = $(element).closest("tr").find(".quantity");
    var editQuantityElement = $(element).closest("tr").find(".edit-quantity");
    quantityElement.hide();
    editQuantityElement.show().focus();
  }

  $(".edit-button").on("click", function (e) {
    e.preventDefault();
    toggleQuantityEdit(this);
  });
  $(".delete-button").on("click", function (e) {
    e.preventDefault();
    // Get the item ID from the data attribute
    var existingIt = getCookie("cart_order");
    console.log(existingIt);

    var itemToDelete = $(this).data("item");
    console.log("My Item" + itemToDelete);

    var selectedIndex = parseInt(
      $(this).closest("tr").find("td:first-child").text()
    );
    selectedIndex = selectedIndex - 1;
    console.log("Child value: " + selectedIndex);

    $.ajax({
      url: "http://localhost/wag/wp-admin/admin-ajax.php",
      type: "POST",
      data: {
        action: "delete_products_from_cart",
        selectedIndex: selectedIndex,
        itemToDelete: itemToDelete,
      },
      success: function (response) {
        $(".response_get").html(response);
      },
      error: function (error) {
        // Handle error
        console.log("AJAX request error:", error);
      },
    });

    // Remove the row from the table
    $(this).closest("tr").remove();
    // Update the cookie by removing the item
    if (typeof Cookies !== "undefined") {
      var cookieValue = Cookies.get("cart_order");
      if (cookieValue) {
        console.log(cookieValue);
        var items = JSON.parse(cookieValue);
        // Find the index of the item in the array
        var index = items.indexOf(itemToDelete);
        console.log(index);
        if (index > -1) {
          // Remove the item from the array
          items.splice(index, 1);
          // Update the cookie with the modified array
          Cookies.set("cart_order", JSON.stringify(items));
        }
      }
    }
  });
});
